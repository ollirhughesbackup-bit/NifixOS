cat << "EOF"
Nifix  0.9.5
write reg: booting 0x0000000F...
OK  [ 0.04 ]
write reg: booting 0x0000000A...
OK  [ 0.04 ]
write reg: booting 0x0000000B...
OK  [ 0.04 ]
write reg: booting 0x0000001K...
OK  [ 0.04 ]
write reg: booting 0x00000006...
OK  [ 0.04 ]
EOF
sleep 1.2
clear
neofetch


